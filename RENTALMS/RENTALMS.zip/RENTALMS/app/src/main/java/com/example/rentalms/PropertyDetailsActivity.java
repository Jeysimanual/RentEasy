package com.example.rentalms;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

public class PropertyDetailsActivity extends AppCompatActivity {

    private TextView propertyNameTextView, cityTextView, priceTextView, typeTextView;
    private ImageView exteriorImageView, interiorImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_property_details);

        propertyNameTextView = findViewById(R.id.propertyNameDetails);
        cityTextView = findViewById(R.id.cityDetails);
        priceTextView = findViewById(R.id.priceDetails);
        typeTextView = findViewById(R.id.typeDetails);
        exteriorImageView = findViewById(R.id.exteriorImage);
        interiorImageView = findViewById(R.id.interiorImage);

        // Retrieve data from the Intent
        String propertyName = getIntent().getStringExtra("propertyName");
        String city = getIntent().getStringExtra("city");
        String price = getIntent().getStringExtra("price");
        String type = getIntent().getStringExtra("type");
        String exteriorImageUrl = getIntent().getStringExtra("exteriorImageUrl");
        String interiorImageUrl = getIntent().getStringExtra("interiorImageUrl");

        // Set data to views
        propertyNameTextView.setText(propertyName);
        cityTextView.setText(city);
        priceTextView.setText("Price: $" + price);
        typeTextView.setText("Type: " + type);

        Glide.with(this).load(exteriorImageUrl).placeholder(R.drawable.default_image).into(exteriorImageView);
        Glide.with(this).load(interiorImageUrl).placeholder(R.drawable.default_image).into(interiorImageView);
    }
}
